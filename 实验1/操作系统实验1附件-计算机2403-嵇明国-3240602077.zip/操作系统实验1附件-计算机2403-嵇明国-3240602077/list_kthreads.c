#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched.h>          /* task_struct、for_each_process、PF_KTHREAD */
#include <linux/sched/signal.h>   /* 进程相关声明（新版内核需要） */

MODULE_LICENSE("GPL");

/* 模块加载函数 */
static int __init list_kthreads_init(void)
{
    struct task_struct *task;

    /* 打印表头，%-20s 表示左对齐占 20 列 */
    printk(KERN_INFO "%-20s %-10s %-10s %-10s %-10s\n",
           "Name", "PID", "State", "Priority", "PPID");

    /* 遍历系统中所有进程（tasks 链表） */
    for_each_process(task) {
        /* PF_KTHREAD 标志置位表示该任务是内核线程 */
        if (task->flags & PF_KTHREAD) {
            /* comm 为进程名（最长 15 个字符）；__state 为任务状态；
               prio 为动态优先级（0~139，普通任务默认 120）；
               parent 为父进程，内核线程通常由 kthreadd 创建 */
            printk(KERN_INFO "%-20s %-10d %-10ld %-10d %-10d\n",
                   task->comm, task->pid, (long)task->__state, task->prio,
                   task->parent ? task->parent->pid : 0);
        }
    }
    return 0;
}

static void __exit list_kthreads_exit(void)
{
    printk(KERN_INFO "list_kthreads module unloaded.\n");
}

module_init(list_kthreads_init);
module_exit(list_kthreads_exit);
