#include <linux/module.h>    /* module_init/module_exit、MODULE_LICENSE 等宏 */
#include <linux/kernel.h>    /* printk 与 KERN_INFO 日志级别 */
#include <linux/init.h>      /* __init、__exit 段属性 */

/* 模块加载函数：执行 sudo insmod 时由内核调用，返回 0 表示加载成功 */
static int __init hello_init(void)
{
    printk(KERN_INFO "hello,world\n");   /* 写入内核日志缓冲区，dmesg 可见 */
    return 0;                            /* 返回 0，模块常驻内核 */
}

/* 模块卸载函数：执行 sudo rmmod 时由内核调用，无返回值 */
static void __exit hello_exit(void)
{
    printk(KERN_INFO "goodbye\n");
}

module_init(hello_init);     /* 向内核注册加载入口 */
module_exit(hello_exit);     /* 向内核注册卸载出口 */
MODULE_LICENSE("GPL");       /* 声明 GPL 许可证，避免内核被标记为 tainted */
MODULE_AUTHOR("jimingguo");
MODULE_DESCRIPTION("A simple Hello World LKM");
