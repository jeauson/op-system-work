#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/sched/signal.h>
#include <linux/list.h>
#include <linux/pid.h>          /* find_vpid、pid_task、PIDTYPE_PID */

MODULE_LICENSE("GPL");

/* 模块参数：加载时由 insmod 传入，如 insmod family.ko pid_to_find=1234 */
static int pid_to_find = 0;
module_param(pid_to_find, int, S_IRUGO);

/* 辅助函数：打印一个任务的角色、名称、PID 与状态 */
void print_task_info(struct task_struct *t, const char *role)
{
    if (t != NULL) {
        printk(KERN_INFO "  [%-10s] Name: %-15s PID: %-6d State: %ld\n",
               role, t->comm, t->pid, (long)t->__state);
    }
}

static int __init process_family_init(void)
{
    struct task_struct *target_task = NULL;
    struct task_struct *child;
    struct list_head *list;

    /* 参数校验：未传参数或传入非法 PID 时返回 -EINVAL */
    if (pid_to_find <= 0) {
        printk(KERN_WARNING "Please provide a PID: "
               "insmod family.ko pid_to_find=1234\n");
        return -EINVAL;
    }

    /* 在当前 PID 命名空间中查找 struct pid，再取出对应的 task_struct */
    target_task = pid_task(find_vpid(pid_to_find), PIDTYPE_PID);
    if (!target_task) {
        printk(KERN_ERR "Process with PID %d not found!\n", pid_to_find);
        return -ESRCH;      /* 对应 insmod 提示 No such process */
    }

    printk(KERN_INFO "--- Family Info for Process: %s (PID: %d) ---\n",
           target_task->comm, target_task->pid);

    /* 1. 父进程：task->parent 直接指向父任务 */
    print_task_info(target_task->parent, "Parent");

    /* 2. 兄弟进程：父进程 children 链表中除自己以外的任务 */
    if (target_task->parent) {
        list_for_each(list, &target_task->parent->children) {
            child = list_entry(list, struct task_struct, sibling);
            if (child->pid != target_task->pid)    /* 排除目标进程自身 */
                print_task_info(child, "Sibling");
        }
    }

    /* 3. 子进程：目标进程自己的 children 链表 */
    list_for_each(list, &target_task->children) {
        child = list_entry(list, struct task_struct, sibling);
        print_task_info(child, "Child");
    }

    printk(KERN_INFO "--------------------------------------------------\n");
    return 0;
}

static void __exit process_family_exit(void)
{
    printk(KERN_INFO "process_family module unloaded.\n");
}

module_init(process_family_init);
module_exit(process_family_exit);
